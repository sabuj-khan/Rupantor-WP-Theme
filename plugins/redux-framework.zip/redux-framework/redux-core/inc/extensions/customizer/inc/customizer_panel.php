<?php
// Shim for the old way of calling the customizer.
require_once dirname( __FILE__ ) . '/class-redux-customizer-panel.php';
