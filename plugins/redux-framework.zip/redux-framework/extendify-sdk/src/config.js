export const templates = {
    defaultType: 'pattern',
    templatesPerRequest: 12,
}
