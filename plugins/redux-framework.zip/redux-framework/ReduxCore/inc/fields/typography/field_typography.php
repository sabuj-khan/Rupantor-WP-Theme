<?php
/**
 * Silence is golden.
 *
 * @package Redux Framework
 */

// Shim file for bad theme developers.

echo null;
