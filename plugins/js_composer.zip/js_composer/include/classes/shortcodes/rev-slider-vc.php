<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Class WPBakeryShortCode_Rev_Slider_Vc
 */
class WPBakeryShortCode_Rev_Slider_Vc extends WPBakeryShortCode {
}
